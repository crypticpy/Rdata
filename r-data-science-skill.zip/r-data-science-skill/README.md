# R Data Science Skill + Sub-agents for Claude Code

A comprehensive Claude Code skill for R programming with 6 specialized sub-agents that auto-invoke based on task context.

## What's Included

```
.claude/
├── skills/
│   └── r-data-science/
│       └── SKILL.md          # Core R knowledge (triggers on .R, .qmd, .Rmd files)
└── agents/
    ├── r-data-wrangler.md    # Data cleaning & transformation
    ├── r-viz-builder.md      # Modern ggplot2 visualizations
    ├── r-stats-analyst.md    # Statistical analysis & epidemiology
    ├── r-report-generator.md # Quarto/RMarkdown reports
    ├── r-dashboard-builder.md # Shiny & Quarto dashboards
    └── r-data-storyteller.md # Stakeholder communication
```

## Installation

### Option 1: Project-Level (Recommended)

Copy both directories to your R project:

```bash
# From your R project root
cp -r .claude/ /path/to/your/project/
```

This makes the skill and agents available only in that project.

### Option 2: User-Level (All Projects)

Install globally so they're available everywhere:

```bash
# Skill
mkdir -p ~/.claude/skills/r-data-science
cp .claude/skills/r-data-science/SKILL.md ~/.claude/skills/r-data-science/

# Agents
mkdir -p ~/.claude/agents
cp .claude/agents/*.md ~/.claude/agents/
```

### Restart Claude Code

After installing, restart Claude Code to load the new skill and agents:

```bash
claude
```

## How It Works

### The Skill (Domain Knowledge)
The `SKILL.md` file provides Claude with R-specific knowledge:
- Tidyverse conventions and style guide
- Common analysis patterns
- Package recommendations
- Code structure templates

**Triggers on:** `.R`, `.qmd`, `.Rmd` files or R-related requests

### The Sub-agents (Specialized Execution)

Each sub-agent:
- Has its own **context window** (doesn't pollute main conversation)
- Uses **Claude Opus 4.5** for maximum capability
- Auto-loads the **r-data-science skill**
- **Auto-invokes** based on task description

| Agent | Triggers On |
|-------|-------------|
| `r-data-wrangler` | "clean data", "reshape", "pivot", "join", "missing values" |
| `r-viz-builder` | "create chart", "plot", "visualization", "ggplot" |
| `r-stats-analyst` | "regression", "odds ratio", "hypothesis test", "confidence interval" |
| `r-report-generator` | "create report", "Quarto document", "write up analysis" |
| `r-dashboard-builder` | "build dashboard", "Shiny app", "interactive display" |
| `r-data-storyteller` | "executive summary", "press release", "explain to leadership" |

## Usage Examples

### Automatic Delegation
Just describe your task—Claude routes to the right agent:

```
> Clean this messy CSV and create age groups
[Auto-uses r-data-wrangler]

> Create an epidemic curve showing weekly cases by region  
[Auto-uses r-viz-builder]

> Calculate odds ratios with 95% CIs for this exposure
[Auto-uses r-stats-analyst]
```

### Explicit Invocation
Request a specific agent:

```
> Use the r-viz-builder agent to make this chart publication-ready
> Have the r-data-storyteller agent write an executive summary
```

### Managing Agents
Use the `/agents` command to view, edit, or create agents:

```
/agents
```

## Customization

### Change the Model
Edit the `model:` field in any agent file:
- `opus` - Most capable (default)
- `sonnet` - Balanced
- `haiku` - Fastest
- `inherit` - Use main conversation's model

### Restrict Tools
Edit the `tools:` field to limit what an agent can do:
```yaml
tools: Read, Grep, Glob  # Read-only agent
```

### Add Your Own Patterns
Edit the system prompt (body) of any agent to add organization-specific conventions, color palettes, or templates.

## Resources

- [Claude Code Sub-agents Documentation](https://code.claude.com/docs/en/sub-agents)
- [Claude Code Skills Documentation](https://code.claude.com/docs/en/skills)
- [Tidyverse Style Guide](https://style.tidyverse.org/)
- [R for Data Science (2e)](https://r4ds.hadley.nz/)
- [The Epidemiologist R Handbook](https://epirhandbook.com/)

## Version

- v2.0.0 (December 2024): Restructured as skill + sub-agents for Claude Code
- v1.0.0 (January 2025): Initial release for PubHealthAI community
